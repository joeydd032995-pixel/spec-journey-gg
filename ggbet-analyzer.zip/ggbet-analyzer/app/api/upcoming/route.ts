/**
 * app/api/upcoming/route.ts
 *
 * GET /api/upcoming[?leagueId=25067]
 *
 * Returns tonight's upcoming fixtures — useful for pre-game setup.
 */

import { NextRequest, NextResponse } from "next/server";
import { BetsAPIClient, DEFAULT_LEAGUE_ID } from "@/lib/betsapi";

export const maxDuration = 30;

export async function GET(req: NextRequest) {
  const token = process.env.BETSAPI_TOKEN;
  if (!token) {
    return NextResponse.json({ error: "BETSAPI_TOKEN not configured." }, { status: 500 });
  }

  const { searchParams } = req.nextUrl;
  const leagueId = parseInt(searchParams.get("leagueId") ?? String(DEFAULT_LEAGUE_ID), 10);

  try {
    const client   = new BetsAPIClient(token);
    const upcoming = await client.fetchUpcoming(leagueId);
    return NextResponse.json({ upcoming, fetched: new Date().toISOString() });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
